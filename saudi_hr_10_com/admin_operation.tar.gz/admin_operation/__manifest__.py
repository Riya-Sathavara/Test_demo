# -*- coding: utf-8 -*-
{
    'name': "Admin Operations",

    'summary': """
	Base Module for Saudi HR.        
""",

    'description': """
        Module provide base functionality for all modules in saudi HR.
    """,

    'author': "Aktiv Software",
    'website': "http://www.aktivsoftware.com",

    'category': 'Employees',
    'version': '0.1',

    'depends': ['hr'],

    'data': [
             'views/ticket_type_view.xml',
             'views/purpose_of_travel_view.xml',
             'views/flight_booking_view.xml',
    ],
}
