# -*- coding: utf-8 -*-

from odoo import fields, models, api


class TicketType(models.Model):
    _name = 'ticket.type'
    
    name = fields.Char('Types of Ticket')
    
class PurposeTravel(models.Model):
    _name = 'travel.purpose'
    
    name = fields.Char('Travel Purpose')
    
class FlightBooking(models.Model):
    _name = 'flight.booking'
    
    ticket_type_id = fields.Many2one('ticket.type', string='Ticket Type', required=True)
    travel_purpose_id = fields.Many2one('travel.purpose', string='Traveling Purpose')
    employee_id = fields.Many2one('hr.employee', string='Employee', required=True)
    employee_ems_code = fields.Char('Employee EMS Code')
    employee_code = fields.Char('Employee Code', readonly=True)
    department_id = fields.Many2one('hr.department', string='Department', readonly=True)
    job_id = fields.Many2one('hr.job', string='Job Position', readonly=True)
    office = fields.Char('Office')
    no_passenger = fields.Integer('No. of Passenger', required=True)
    start_date = fields.Date('Preferred Start Date', required=True)
    travel_from = fields.Many2one('res.country', string='Country From', required=True)
    travel_to = fields.Many2one('res.country', string='Country To', required=True)
    traveling_date_from = fields.Date('Traveling From Date', required=True)
    traveling_date_to = fields.Date('Traveling To Date', required=True)
    type = fields.Selection([('one_way', 'One Way'), ('two_way', 'Two Way')], string='Type', required=True)
    state = fields.Selection([('draft', 'Draft'), ('waiting_for_approval', 'Waiting for approval'), ('validate', 'Validate'), ('approved', 'Approved'), ('refuse', 'Refuse'), ('cancel', 'Cancel')],default='draft', string='State')
    description = fields.Text('Description')